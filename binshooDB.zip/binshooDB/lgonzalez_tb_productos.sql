CREATE DATABASE  IF NOT EXISTS `lgonzalez` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `lgonzalez`;
-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: lgonzalez
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_productos`
--

DROP TABLE IF EXISTS `tb_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_productos` (
  `id_producto` int NOT NULL,
  `nombre_producto` varchar(150) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `precio_producto` float NOT NULL,
  `foto_producto` varchar(900) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `categoria` int NOT NULL,
  `is_top_selling` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_productos`
--

LOCK TABLES `tb_productos` WRITE;
/*!40000 ALTER TABLE `tb_productos` DISABLE KEYS */;
INSERT INTO `tb_productos` VALUES (1,'California Roll',5.18,'https://assets.tmecosys.cn/image/upload/t_web767x639/img/recipe/ras/Assets/54C547F3-4CAD-4392-B299-7044C15249C8/Derivates/4baaf57e-bcce-4f1f-b437-1916f68c9640.jpg',1,1),(2,'Kimchi',4.5,'https://images.unsplash.com/photo-1583224964978-2257b960c3d3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80',6,1),(3,'Biryani',3.99,'https://static.toiimg.com/photo/54308405.cms',3,1),(4,'Tsukemen Ramen',14.84,'https://images.rappi.com.mx/products/2110516261-1635343829381.jpg',1,0),(5,'Punjabi Samosa',2.99,'https://d1q7fw5qeu4nx.cloudfront.net/wp-content/uploads/sites/2/2018/10/04113323/Pork-Mince-Samosas-2400x1800.jpg',3,0),(6,'Bibimbap',8.99,'https://i.blogs.es/cc055c/bibimbap/840_560.jpg',6,0),(7,'Chicken Katsu Curry',8.99,'https://www.cookerru.com/wp-content/uploads/2020/08/chicken-katsu-curry-1-recipe-new.jpg',1,0),(8,'Yasai Gyoza',4.99,'https://www.justonecookbook.com/wp-content/uploads/2020/04/Gyoza-3107-IV.jpg',1,0),(9,'Miso Shiru',2.5,'https://www.pressurecookrecipes.com/wp-content/uploads/2021/05/miso-soup.jpg',1,0),(10,'Lamb Curry',7.99,'https://www.simplyrecipes.com/thmb/QH2aDqzxsZusEW1U6j1sztImyRU=/1400x933/filters:fill(auto,1)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2005__02__lamb-curry-horiz-a-1400-dc279dc515bf459185af66c257f4be63.jpg',3,0),(11,'Paneer Makhani',8.99,'https://assets.tmecosys.com/image/upload/t_web767x639/img/recipe/vimdb/163894_0-840-5478-5478.jpg',3,0),(12,'Pad Phed',8.55,'https://homecooksclassroom.com/wp-content/uploads/2020/05/pad-prik-king.jpg',4,0),(13,'Pad Ce-Eaw',9.95,'https://www.cocinista.es/download/bancorecursos/recetas/receta_pad_see_ew_2.jpg',4,0);
/*!40000 ALTER TABLE `tb_productos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-22 20:07:38
